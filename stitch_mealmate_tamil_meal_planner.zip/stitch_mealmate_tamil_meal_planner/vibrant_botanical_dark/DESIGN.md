---
name: Vibrant Botanical Dark
colors:
  surface: '#09160e'
  surface-dim: '#09160e'
  surface-bright: '#2f3c33'
  surface-container-lowest: '#051109'
  surface-container-low: '#111e16'
  surface-container: '#15221a'
  surface-container-high: '#202d24'
  surface-container-highest: '#2a382f'
  on-surface: '#d7e6d9'
  on-surface-variant: '#c2cab0'
  inverse-surface: '#d7e6d9'
  inverse-on-surface: '#26332b'
  outline: '#8c947c'
  outline-variant: '#424936'
  surface-tint: '#98da27'
  primary: '#ccff80'
  on-primary: '#213600'
  primary-container: '#a3e635'
  on-primary-container: '#416400'
  inverse-primary: '#446900'
  secondary: '#ffb95f'
  on-secondary: '#472a00'
  secondary-container: '#ee9800'
  on-secondary-container: '#5b3800'
  tertiary: '#ffeae8'
  on-tertiary: '#68000a'
  tertiary-container: '#ffc4bf'
  on-tertiary-container: '#b31420'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#b2f746'
  primary-fixed-dim: '#98da27'
  on-primary-fixed: '#121f00'
  on-primary-fixed-variant: '#334f00'
  secondary-fixed: '#ffddb8'
  secondary-fixed-dim: '#ffb95f'
  on-secondary-fixed: '#2a1700'
  on-secondary-fixed-variant: '#653e00'
  tertiary-fixed: '#ffdad7'
  tertiary-fixed-dim: '#ffb3ad'
  on-tertiary-fixed: '#410004'
  on-tertiary-fixed-variant: '#930013'
  background: '#09160e'
  on-background: '#d7e6d9'
  surface-variant: '#2a382f'
typography:
  display-lg:
    fontFamily: Inter
    fontSize: 40px
    fontWeight: '700'
    lineHeight: 48px
    letterSpacing: -0.02em
  display-lg-mobile:
    fontFamily: Inter
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Inter
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 36px
    letterSpacing: -0.015em
  headline-md:
    fontFamily: Inter
    fontSize: 22px
    fontWeight: '600'
    lineHeight: 30px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 26px
    letterSpacing: -0.005em
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 22px
  body-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 18px
  label-lg:
    fontFamily: Noto Sans
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.01em
  label-md:
    fontFamily: Noto Sans
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.02em
  label-sm:
    fontFamily: Noto Sans
    fontSize: 10px
    fontWeight: '700'
    lineHeight: 14px
    letterSpacing: 0.04em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  space-2xs: 0.25rem
  space-xs: 0.5rem
  space-sm: 0.75rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
  space-2xl: 3rem
  gutter-mobile: 1rem
  gutter-desktop: 1.5rem
  margin-mobile: 1rem
  margin-tablet: 2rem
  margin-desktop: 3rem
---

## Brand & Style

This design system expresses culinary intuition through an elevated, contemporary botanical dark theme. Tailored for an Indian context, it marries high-tech AI meal intelligence with sensory gastronomic warmth. 

The mood combines the discipline of high-end culinary curation with the kinetic energy of South Indian and pan-Indian kitchens. The aesthetic balances deep forest darkness with vibrant chlorophyll-infused lime accents, punctuated by culinary spices—mustard seed, fiery dried chili, and warm turmeric.

The visual style merges modern fluid tactile layering with subtle glassmorphic sheen:
- Deep, desaturated organic greens form immersive, low-glare dark surfaces that avoid stark amoled blacks.
- High-chroma lime elements act as precise cognitive focal points for AI suggestions, primary interactive triggers, and dynamic macros.
- Bilingual typography creates seamless visual parity between Tamil and English typography across all meal recommendations, ingredient breakdowns, and voice prompts.

## Colors

The palette avoids sterile neutrals, grounding the entire interface in deep emerald-tinted obsidian tones that evoke rich soil, cast iron, and banana leaf textures.

### Canvas & Surface Hierarchy
- **Base Surface (`#0B130E`):** The foundational canvas. Ultra-deep emerald tone providing infinite depth and optical comfort in dim lighting.
- **Surface Level 1 (`#121F17`):** Elevated cards, ingredient shelves, and meal plan tiles.
- **Surface Level 2 (`#1A2E22`):** Interactive inputs, nested tags, and overlay sheets.
- **Surface Level 3 (`#233B2C`):** High-interaction states, active meal slots, and hover fills.

### Accents & Dynamic Semantics
- **Electric Lime Primary (`#A3E635` / `#84CC16`):** The voice of the AI assistant, call-to-action buttons, nutrient optimization states, and macro completion bars.
- **Mint Vitality (`#4ADE80`):** Secondary success indicators, fresh herb cues, and vegan/vegetarian dietary flags.
- **Warm Turmeric / Amber (`#F59E0B`):** Warm breakfast meal flags, savory spice tags, warning states, and cooking time metadata.
- **Chili Red (`#EF4444`):** High spice levels, non-vegetarian dietary badges, allergen flags, and destructive dismissals.
- **Text Primary (`#F1F5F2`):** 96% high-legibility off-white with an organic warm tint.
- **Text Muted (`#8DA394`):** Mid-tone sage gray maintaining WCAG AA contrast for secondary ingredient labels and nutritional metrics.

## Typography

Typography balances Latin modernism with the curvilinear density of Tamil script. Inter handles Latin UI elements and alphanumeric values, while Noto Sans Tamil supports complete Unicode script coverage for native Tamil rendering.

### Script Pairing & Vertical Alignment
Tamil script carries taller vowel ascenders and deeper descenders than Latin typefaces. When bilingual labels or dynamic language toggling occurs:
- Increase standard line heights by 4px on body containers rendering Tamil text.
- Match apparent optical size rather than point size; Tamil glyphs should be set 1px smaller than Latin counterparts if placed inline side-by-side to maintain balance.
- Avoid all-caps or artificial letter-spacing when rendering Tamil script strings. Reserve tracking adjustments exclusively for uppercase Latin labels.

## Layout & Spacing

The layout is constructed on an 8-point base spatial grid, scaled to 4px intervals for tight density controls (such as micro-nutrient chips and pantry quantity counters).

### Form Factors & Adaptation
- **Mobile (< 768px):** Single-column dynamic feed. Spacing utilizes `margin-mobile` (16px) with an edge-to-edge bleed for horizontal recipe scrollers. Sticky action bars reserve 88px clearance at screen bottom to support the elevated tactile voice orb.
- **Tablet (768px - 1023px):** Dual-column asymmetrical layout. The left column (40% width) locks the daily meal calendar and dietary tracker, while the right column (60% width) presents the recipe cards and grocery distribution lists.
- **Desktop (≥ 1024px):** 12-column fluid grid constrained to a maximum width of 1280px. 3-column meal orchestration: Week Overview (3 cols), Active Meal AI Generator (6 cols), Pantry & Spice Matrix (3 cols).

## Elevation & Depth

Visual hierarchy uses luminous ambient radiance, translucent materials, and tonal stratification.

### Surface Tiers & Translucency
- **Ground (`#0B130E`):** Static background layer. Contains subtle radial ambient glows (`rgba(132, 204, 22, 0.04)`) aligned behind interactive hero sections.
- **Level 1 (`#121F17`):** Base structural cards. Sealed with a fine outline of `rgba(255, 255, 255, 0.06)` to retain crisp definition without casting heavy shadows.
- **Level 2 (`#1A2E22`):** Elevated overlays, modal bottom sheets, and dropdown selectors. Augmented with an extra-diffused ambient shadow: `0 16px 32px -8px rgba(0, 0, 0, 0.6)`.
- **Level 3 (`#121F17` at 85% opacity with `backdrop-filter: blur(16px)`):** Sticky headers and top navigation banners. Allows colorful food imagery to subtly register through during scroll.

### Luminescent Accents
- The primary AI Floating Action Button (FAB) uses radiant neon energy: `0 0 0 2px #A3E635, 0 8px 24px 0 rgba(163, 230, 53, 0.35)`.
- Active meal state borders use a 1.5px gradient border running from `#A3E635` to `#4ADE80` with a soft outer atmospheric glow: `0 0 16px rgba(163, 230, 53, 0.15)`.

## Shapes

The design system employs a rounded, organic geometry (`roundedness: 2`) that reflects natural elements—smooth culinary stones, curry leaves, and hand-formed vessels.

- Standard cards, interactive containers, and modal dialogs adopt a 16px (`rounded-lg`) radius.
- Action tags, food dietary chips, text inputs, and category pills use full pill shaping (`rounded-full` / 9999px) to invite direct fingertip tapping.
- Recipe imagery within food cards has a unified 12px inner corner radius, maintaining a consistent 4px concentric offset relative to the parent card's 16px radius.

## Components

### Buttons & Voice Trigger
- **Primary CTA:** Background `#A3E635`, text `#0B130E` (bold weight for contrast), pill-shaped. On press: scales to `0.97` with background stepping down to `#84CC16`.
- **Secondary Action:** Glass style; background `#1A2E22`, border 1px solid `rgba(255, 255, 255, 0.12)`, text `#F1F5F2`.
- **Floating Voice Assistant Button (The Voice Orb):** Fixed bottom-center or bottom-right. 64px circular container, background `#121F17` framed with a dual-layer ring: inner 2px lime stroke (`#A3E635`), outer pulsating ambient aura (`rgba(163, 230, 53, 0.25)`). Accommodates animated audio waveforms during Tamil/English voice inputs.

### Chips & Dietary Markers
- **Veg Indicator Chip:** Border and text `#4ADE80`, background `rgba(74, 222, 128, 0.08)`, 12px height dot inside a square frame.
- **Non-Veg Indicator Chip:** Border and text `#EF4444`, background `rgba(239, 68, 68, 0.08)`, 12px height triangle inside a square frame.
- **Spice Intensity Chip:** Chili red background tint (`rgba(239, 68, 68, 0.15)`), displaying red flame/chili icons and spice grade in localized copy (e.g., "Mild" / "மிதமான", "Spicy" / "காரமான").
- **Meal Prep / Prep-Time Chip:** Turmeric amber pill (`rgba(245, 158, 11, 0.12)`), text `#F59E0B`.

### Recipe & Meal Cards
- Constructed on `#121F17` with subtle 1px border `rgba(255, 255, 255, 0.05)`.
- Image occupies the top half with a natural bottom gradient feathering into the card base.
- Title row holds bilingual headline support (English item with smaller Tamil transliteration underneath, or vice versa).
- Bottom row features macro distribution: compact micro-meters showing Protein, Carbs, and Fats using `#A3E635`, `#F59E0B`, and `#4ADE80`.

### Form Fields & Inputs
- **Search & Ingredient Filters:** Background `#1A2E22`, border 1px solid `rgba(255, 255, 255, 0.08)`, rounded-full. Focus state replaces the border with `#A3E635` and adds a 2px lime glow (`rgba(163, 230, 53, 0.2)`).
- **Voice-to-Text Input Mode:** Expands the field into an animated soundwave ribbon resting above the keyboard, confirming language detection ("Listening in Tamil / தமிழில் கேட்கிறது...").

### Checkboxes & Radio Controls
- Circular checks styled with `#A3E635` fill on active state with high-contrast `#0B130E` checkmark glyph. Unchecked states hold an inset 1.5px stroke of `#8DA394`.